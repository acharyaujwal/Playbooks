#!/bin/bash
#scp -r /opt/metron_files/localrepo root@$ambari_ip:/
#scp -r /opt/metron_files/localrepo root@$metron_ip:/
#scp -r /opt/metron_files/localrepo root@$node1_ip:/
scp -r /opt/metron_files/localrepo root@192.168.1.122:/opt
