scp -r /opt/metron_files/localrepo/* root@{{ ambari_ip }}:/localrepo/
